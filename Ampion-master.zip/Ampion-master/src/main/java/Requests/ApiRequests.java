package Requests;

import kong.unirest.HttpResponse;
import kong.unirest.JsonNode;
import kong.unirest.Unirest;
import kong.unirest.json.JSONArray;
import kong.unirest.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.*;


public class ApiRequests {

    String updatedDate;
    static String postCode;
    private String apiKey = "8735119f5c604c93a5fcdace639667a5";
    private static List<String> fullListWithDetails = new ArrayList<String>();

    SimpleDateFormat dateFormatterNew = new SimpleDateFormat("EEEE, MMM d, yyyy");

    public void sendRequestAndSetResponse(String dataType, String value) throws ParseException {
        postCode = value;
        HttpResponse<JsonNode> response = Unirest.post("https://api.weatherbit.io/v2.0/forecast/daily")
                .queryString("key", apiKey)
                .queryString(dataType, value)
                .asJson();

        parseResponseAndSetData(response);
    }

    private void parseResponseAndSetData(final HttpResponse<JsonNode> response) throws ParseException {
        JSONObject object = response.getBody().getObject();
        JSONArray array = object.getJSONArray("data");
        for (int i = 0; i < 16; i++) {
            updateAndSetNewDateFormat(array.getJSONObject(i).get("valid_date").toString());
            if (validateIfDayIsMonOrFri()) {
                if (validateTempIsCorrect(Double.parseDouble(array.getJSONObject(i).get("temp").toString()))) {
                    if (validateWindSpeedIsCorrect(Double.parseDouble(array.getJSONObject(i).get("wind_spd").toString()))) {
                        if (validateUVIsCorrect(Double.parseDouble(array.getJSONObject(i).get("uv").toString()))) {
                            fullListWithDetails.add(updatedDate + " with avg temperature of " + Double.parseDouble(array.getJSONObject(i).get("temp").toString())
                            + " and wind speed of " + Double.parseDouble(array.getJSONObject(i).get("wind_spd").toString())
                            + " and UV of " + Double.parseDouble(array.getJSONObject(i).get("uv").toString()));
                        }
                    }
                }
            }
        }
    }

    private void updateAndSetNewDateFormat(String date) throws ParseException {
        String year = date.split("-")[0];
        String month = date.split("-")[1];
        String day = date.split("-")[2];

        Date d = new  SimpleDateFormat("dd/MM/yyyy").parse(day + "/" + month + "/" + year);
        updatedDate = dateFormatterNew.format(d);
    }

    private boolean validateIfDayIsMonOrFri() {
        if (updatedDate.contains("Mon") || updatedDate.contains("Fri")) {
            return true;
        }
        return false;
    }

    private boolean validateTempIsCorrect(double temp) {
        if (temp > 12 && temp < 30) {
            return true;
        }
        return false;
    }

    private boolean validateWindSpeedIsCorrect(double speed) {
        if (speed > 3 && speed < 9) {
            return true;
        }
        return false;
    }

    private boolean validateUVIsCorrect(double uV) {
        if (uV <= 12) {
            return true;
        }
        return false;
    }

    public static void outputSurfConditionsForNext16Days() {
        Set<String> dateSet = new LinkedHashSet<>(fullListWithDetails);
        for (String date : dateSet) {
            System.out.println(String.format("Surfing conditions look good in area %s on %s", postCode, date));
        }
    }
}
