package StepDefinitions;

import Requests.ApiRequests;
import cucumber.api.java.en.Then;

public class ThenSteps {

    @Then("^I should see which days will be suitable for a surf$")
    public void outputSurfConditions() {
        ApiRequests.outputSurfConditionsForNext16Days();
    }
}
