package StepDefinitions;

import Requests.ApiRequests;
import cucumber.api.DataTable;
import cucumber.api.java.en.Given;

import java.text.ParseException;
import java.util.Map;

public class GivenSteps {

    @Given("^I make the below api calls to the weather map$")
    public void makeWeatherApiCalls(DataTable dataTable) throws ParseException {
        ApiRequests apiRequests = new ApiRequests();
        Map<String, String> data = dataTable.asMap(String.class, String.class);
        for (Map.Entry<String, String> set : data.entrySet()) {
            apiRequests.sendRequestAndSetResponse(set.getKey(), set.getValue());
            }
        }
    }
